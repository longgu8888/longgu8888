package jp.sourceforge.mergedoc;

import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.jdt.internal.ui.JavaPlugin;
import org.eclipse.jdt.ui.JavaUI;
import org.eclipse.search.ui.NewSearchUI;
import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;
import org.eclipse.ui.console.IConsoleConstants;
import org.eclipse.ui.progress.IProgressConstants;
import org.eclipse.ui.texteditor.templates.TemplatesView;

public class PleiadesJavaPerspectiveFactory implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {

 		String editorArea = layout.getEditorArea();

		IFolderLayout output = layout.createFolder("output", IPageLayout.LEFT, 0.5f, editorArea);
		output.addView(IPageLayout.ID_PROBLEM_VIEW);
		output.addPlaceholder(JavaUI.ID_JAVADOC_VIEW);
		output.addPlaceholder(JavaUI.ID_SOURCE_VIEW);
		output.addPlaceholder(NewSearchUI.SEARCH_VIEW_ID);
		output.addPlaceholder(IConsoleConstants.ID_CONSOLE_VIEW);
		output.addPlaceholder(IPageLayout.ID_BOOKMARKS);
		output.addPlaceholder(IProgressConstants.PROGRESS_VIEW_ID);

		IFolderLayout explorer = layout.createFolder("explorer", IPageLayout.TOP, 0.6f, "output");
		explorer.addView(JavaUI.ID_PACKAGES);
		explorer.addPlaceholder(JavaUI.ID_TYPE_HIERARCHY);
		explorer.addPlaceholder(JavaPlugin.ID_RES_NAV);
		explorer.addPlaceholder(IPageLayout.ID_PROJECT_EXPLORER);
		explorer.addPlaceholder(TemplatesView.ID);

		IFolderLayout outline = layout.createFolder("outline", IPageLayout.RIGHT, 0.5f, "explorer");
		outline.addView(IPageLayout.ID_OUTLINE);

		layout.addActionSet(IDebugUIConstants.LAUNCH_ACTION_SET);
		layout.addActionSet(JavaUI.ID_ACTION_SET);
		layout.addActionSet(JavaUI.ID_ELEMENT_CREATION_ACTION_SET);
		layout.addActionSet(IPageLayout.ID_NAVIGATE_ACTION_SET);

		// Java ビュー
		layout.addShowViewShortcut(JavaUI.ID_PACKAGES);
		layout.addShowViewShortcut(JavaUI.ID_TYPE_HIERARCHY);
		layout.addShowViewShortcut(JavaUI.ID_SOURCE_VIEW);
		layout.addShowViewShortcut(JavaUI.ID_JAVADOC_VIEW);

		// 検索ビュー
		layout.addShowViewShortcut(NewSearchUI.SEARCH_VIEW_ID);

		// デバッグ・ビュー
		layout.addShowViewShortcut(IConsoleConstants.ID_CONSOLE_VIEW);

		// 標準ワークベンチ・ビュー
		layout.addShowViewShortcut(IPageLayout.ID_OUTLINE);
		layout.addShowViewShortcut(IPageLayout.ID_PROBLEM_VIEW);
		layout.addShowViewShortcut(JavaPlugin.ID_RES_NAV);
		layout.addShowViewShortcut(IProgressConstants.PROGRESS_VIEW_ID);
		layout.addShowViewShortcut("org.eclipse.pde.runtime.LogView");

		// 新規アクション - Java プロジェクト作成ウィザード
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.JavaProjectWizard");
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.NewPackageCreationWizard");
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.NewClassCreationWizard");
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.NewInterfaceCreationWizard");
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.NewEnumCreationWizard");
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.NewAnnotationCreationWizard");
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.NewSourceFolderCreationWizard");
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.NewSnippetFileCreationWizard");
		layout.addNewWizardShortcut("org.eclipse.jdt.ui.wizards.NewJavaWorkingSetWizard");
		layout.addNewWizardShortcut("org.eclipse.ui.wizards.new.folder");
		layout.addNewWizardShortcut("org.eclipse.ui.wizards.new.file");
		layout.addNewWizardShortcut("org.eclipse.ui.editors.wizards.UntitledTextFileWizard");

		// ウィンドウ > パースペクティブを開く
		layout.addPerspectiveShortcut(JavaUI.ID_BROWSING_PERSPECTIVE);
		layout.addPerspectiveShortcut(IDebugUIConstants.ID_DEBUG_PERSPECTIVE);
	}
}

